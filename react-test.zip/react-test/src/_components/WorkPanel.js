import React from "react";
import { useNavigate } from "react-router";

function WorkPanel(props) {
  const {
    imagePath,
    title,
    context,
    link,
    align,
    color,
    leftSize,
    rightSize,
    rounded,
    imgSize,
    textSize,
  } = props;
  const navigate = useNavigate();
  return (
    <>
      <div
        className={` flex text-left items-center gap[32px] ${rounded} ${
          align === "left"
            ? "xl:flex-row lg:flex-row md:flex-row flex-col"
            : "md:flex-row-reverse  lg:flex-row-reverse xl:flex-row-reverse sm:flex-row-reverse  flex-col"
        }  ${color !== "" ? `bg-[${color}]` : ""} xl:p-0 p-10`}
        style={{ background: `${color !== "" ? `${color}` : ""}` }}
      >
        <div
          style={{
            width: `${
              window.matchMedia("(max-width: 600px)").matches
                ? "100%"
                : leftSize
            }`,
          }}
        >
          <div className="xl:p-[32px] p-0">
            <img
              src={imagePath}
              alt={title}
              width={imgSize}
              // className="max-w-md"
            />
          </div>
        </div>
        <div
          className="xl:p-8 p-2"
          style={{
            width: `${
              window.matchMedia("(max-width: 600px)").matches
                ? "100%"
                : rightSize
            }`,
          }}
        >
          <h2 className={`text-white service-title pb-6 xl:${textSize}`}>
            {title}
          </h2>
          <div className="text-white sub_heading">{context}</div>
          <button
            className="pointer rounded-full mt-5 bg-white p-3 px-10 text-slate-950"
            onClick={() => navigate(link)}
            type="button"
          >
            Learn more
          </button>
        </div>
      </div>
    </>
  );
}

export default WorkPanel;
