import React from "react";
import { networks } from "../data";

function Networks() {
  return (
    <div className="xl:p-10 lg:p-4 p-4">
      <h2 className="team_main_title">Secure networks for teams of any size</h2>
      <div className="netWorkwrapper">
        <ul className="flex xl:flex-row md:flex-row flex-col flex-wrap lg:flex-nowrap ">
          {networks.map((item, index) => (
            <li
              key={index}
              className="xl:network_list lg:network_list  lg:w-1/2 xl:w-1/2 md:w-1/2  px-10"
            >
              <div className="flex flex-col items-center">
                <div className="px-10">
                  <img
                    src={item.icon}
                    alt="imagename"
                    className="xl:w-40 w-72"
                  />
                </div>
                <h2 className="text-center networktitle text-white">
                  {item.title}
                </h2>
                <div className="network-contenxt">{item.context}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Networks;
