export const teams = [
  {
    icon: "https://www.zerotier.com/static/6ef0d11bd53a0e07913da12681ac3522/c45f5/User_Icon_01c147556c.webp",
    context: (
      <>
        <p>
          "Metropolis deploys computer vision in parking lots & car wash
          facilities across the US, integrating ZeroTier to eliminate the
          complexity of managing multiple, disparate networks to deliver a
          seamless, groundbreaking and world-class customer experience."
        </p>
        <p>TODD SHIPWAY, HEAD OF TECHNICAL OPERATIONS, METROPOLIS</p>
      </>
    ),
  },
  {
    icon: "https://www.zerotier.com/static/6ef0d11bd53a0e07913da12681ac3522/c45f5/User_Icon_01c147556c.webp",
    context: (
      <>
        <p>
          "In early product development, we needed a way to easily connect our
          growing IoT product-base to our systems. ZeroTier provided an easy,
          and reliable way to achieve that, and has been growing with us."
        </p>
        <p>PETER BOIN, PRINCIPAL SOFTWARE ENGINEER, ALLUME ENERGY</p>
      </>
    ),
  },
  {
    icon: "https://www.zerotier.com/static/6ef0d11bd53a0e07913da12681ac3522/c45f5/User_Icon_01c147556c.webp",
    context: (
      <>
        <p>
          "ZeroTier provides a robust and essential backbone for our
          communications stack."
        </p>
        <p>ANDREW LIPSCOMB, MECHATRONICS ENGINEER, SWARMFARM ROBOTICS</p>
      </>
    ),
  },
  {
    icon: "https://www.zerotier.com/static/6ef0d11bd53a0e07913da12681ac3522/c45f5/User_Icon_01c147556c.webp",
    context: (
      <>
        <p>
          "Loft Orbital uses ZeroTier to improve interoperability between its
          offices in the United States and France. It connects our engineers to
          key resources quickly and easily, which allows our team to focus on
          making space simple."
        </p>
        <p>BRUNSTON POON, SOFTWARE ENGINEER, LOFT ORBITAL</p>
      </>
    ),
  },
];

export const networks = [
  {
    title: "Individuals",
    icon: "https://www.zerotier.com/static/8a85fc56f42df4c757170636612573f4/1e526/game_icon_eba3d81511.webp",
    context: (
      <>
        <p>
          Access your computers, NAS, home automation, IP cameras, ham radios or
          other devices from anywhere
        </p>
        <p>
          Conveniently share files and data, or even play LAN games with others
        </p>
        <p>Manage secure network access to users of choice</p>
      </>
    ),
  },
  {
    title: "IT Teams",
    icon: "https://www.zerotier.com/static/a24340474cb83819c6d6a0f2a5c8b481/1e526/Cloud_Icon_3a0e68dbd5.webp",
    context: (
      <>
        <p>
          Simplify your network stack by unifying VPNs, VLANs, and SD-WANs with
          one solution
        </p>
        <p>
          Build, manage, and observe any number of remote, on premise, or cloud
          networks with one management interface
        </p>
        <p>Easily provision remote access for all of your users</p>
      </>
    ),
  },
  {
    title: "DevOps",
    icon: "https://www.zerotier.com/static/9805ec01fae783e135a667da3294ca30/1e526/Dev_Ops_Icon_007d67a039.webp",
    context: (
      <>
        <p>
          Quickly build backplane networks spanning multiple cloud providers
        </p>
        <p>Save on performance, storage, and bandwidth</p>
        <p>Administrate and debug from anywhere</p>
        <p>Secure corporate network overlay and failover layer</p>
      </>
    ),
  },
  {
    title: "Embedded",
    icon: "https://www.zerotier.com/static/1dd3895e75e865b9ea36aa98fb36dba5/1e526/Global_Network_Icon_e85c3eca3d.webp",
    context: (
      <>
        <p>Enjoy vastly superior network control and functionality</p>
        <p>
          Develop and manage products or services running on their own
          decentralized networks
        </p>
        <p>
          Create 4G/5G-capable secure networks for any IoT, edge or embedded
          device that can operate on 64MB of RAM
        </p>
      </>
    ),
  },
];

export const footerData = [
  {
    title: "GET STARTED",
    lists: [
      {
        name: "Download",
        link: "",
      },
      {
        name: "Github",
        link: "",
      },
      {
        name: "SDK",
        link: "",
      },
      {
        name: "Partners",
        link: "",
      },
    ],
  },
  {
    title: "SUPPORT",
    lists: [
      {
        name: "Documentation",
        link: "",
      },
      {
        name: "Knowledge Base",
        link: "",
      },
      {
        name: "Community",
        link: "",
      },
      {
        name: "Getting Started",
        link: "",
      },
    ],
  },
  {
    title: "COMPANY",
    lists: [
      {
        name: "Contact",
        link: "",
      },
      {
        name: "About Us",
        link: "",
      },
      {
        name: "Careers",
        link: "",
      },
      {
        name: "Blog",
        link: "",
      },
      {
        name: "Media Kit",
        link: "",
      },
    ],
  },
];

export const priceData = [
  {
    title: "Basic",
    icon: "https://www.zerotier.com/static/e92607a0214589a500caf5cae2f11090/b16a9/Zero_Tier_Logo_Inverted_White_73e6fee0b9.webp",
    conntent: "For Everyone / ZeroTier Hosted Controller",
    buttonColor: `#ffffff`,
    buttonText: "Free Sign Up",
    lists: [
      {
        name: "✓ 1 Admin",
        link: "",
      },
      {
        name: "✓ 25 Nodes",
        link: "",
      },
      {
        name: "✓ Unlimited Networks",
        link: "",
      },
      {
        name: "✖ Business SSO: n/a",
        link: "",
      },
      {
        name: "✓ Community Support",
        link: "",
      },
      {
        name: "FREE",
        link: "",
      },
    ],
  },
  {
    title: "Professional",
    icon: "https://www.zerotier.com/static/794e03fb936295d0ab7d53d51d73550b/b16a9/Zero_Tier_Logo_Orange_a60eff7c4a.webp",
    conntent: "Licensed Only For Individuals and Testing",
    buttonColor: "#ffb441",
    buttonText: "Sing Up",
    lists: [
      {
        name: "✓ Admins | $10 USD/mo each",
        link: "",
      },
      {
        name: "✓ 25 Node Packs | $5 USD/mo",
        link: "",
      },
      {
        name: "✓ Unlimited Networks",
        link: "",
      },
      {
        name: "✓ Business SSO | $5 USD/mo per seat",
        link: "",
      },
      {
        name: "✓ Community Support",
        link: "",
      },
      {
        name: "Starting at $5 USD/month",
        link: "",
      },
    ],
  },
  {
    title: "Business",
    icon: "https://www.zerotier.com/static/dccd19c2abf4ded3547eda65dab7d02e/b16a9/Zero_Tier_Logo_Blue_1c2a591633.webp",
    conntent: "Licensed for Commercial Deployments",
    buttonColor: "#4436ca",
    buttonText: "Contact Sales",
    lists: [
      {
        name: "Use Cases Include",
        link: "",
      },
      {
        name: "∙ IoT/IIoT",
        link: "",
      },
      {
        name: "∙ SD-WAN",
        link: "",
      },
      {
        name: "∙ VPN",
        link: "",
      },
      {
        name: "∙ Remote Monitoring and Management",
        link: "",
      },
      {
        name: "Contact Sales for Pricing",
        link: "",
      },
    ],
  },
];
