import React from "react";
import { priceData } from "../data";

function Pricing() {
  return (
    <div className="xl:p-10 lg:p-10 p-5">
      <h2 className="team_main_title">Pricing</h2>
      <h4 className="text-white text-lg pb-10">
        ZeroTier makes networking easy for everyone - anywhere.
      </h4>
      <div className="wrapper md:w-10/12">
        <ul className="flex gap-8 flex-col xl:flex-row md:flex-col lg:flex-row  ">
          {priceData.map((item, index) => (
            <li
              key={index}
              className="bg-[#262626] xl:w-4/12 lg:w-4/12 md:w-full rounded-xl pt-8 px-4"
            >
              <div className="flex flex-col items-center">
                <div className="px-10 ">
                  <img src={item.icon} alt="imagename" width={64} />
                </div>
                <h2 className="text-center text-3xl  text-white pt-8 pb-4">
                  {item.title}
                </h2>
                <div className="pb-4 text-lg text-white">{item.conntent}</div>
              </div>
              <ul>
                {item.lists.map((childitem, childidex) => (
                  <li className="py-4 text-white text-lg" key={childidex}>
                    {childitem.name}
                  </li>
                ))}
              </ul>
              <a
                href="/"
                className={`bg-[${item.buttonColor}] inline-block rounded-full p-3 px-10 my-5`}
                style={{ backgroundColor: `${item.buttonColor}` }}
              >
                {item.buttonText}
              </a>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Pricing;
