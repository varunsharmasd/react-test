import React from "react";
import { teams } from "../data";

function Teams() {
  return (
    <div className="xl:p-10 lg:p-4 p-4">
      <h2 className="team_main_title md:text-4xl md:pb-8">
        Used by the world's most innovative teams
      </h2>
      <div className="wrapper">
        <ul className="team_under_list">
          {teams.map((item, index) => (
            <li key={index} className="team_list rounded-3xl">
              <div className="flex gap-5">
                <div className="tem-icon">
                  <img src={item.icon} alt="imagename" />
                </div>
                <div className="team_contet">{item.context}</div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}

export default Teams;
