import React from "react";
import WorkPanel from "./WorkPanel";

function Plan() {
  return (
    <div className="wrapper xl:p-0 p-5">
      <div className="mb-14 ">
        <WorkPanel
          imagePath="https://www.zerotier.com/static/7f3f0800479132383698966a2145ee76/1e526/Continuous_Integration_ee887d3f58.webp"
          title="ZeroTier Enterprise"
          context={
            <>
              For high-volume VPN, IoT, IIoT, edge, embedded networking, multi &
              hybrid cloud, Infrastructure as Code (IaC), and Commercial Use.
            </>
          }
          align="right"
          link=""
          color="#4436ca"
          leftSize="33% "
          rightSize="66.666%"
          rounded="rounded-xl"
          imgSize="376"
          textSize="text-size42"
        />
      </div>
      <div>
        <WorkPanel
          imagePath="https://www.zerotier.com/static/7f3f0800479132383698966a2145ee76/1e526/Continuous_Integration_ee887d3f58.webp"
          title="ZeroTier Enterprise"
          context={
            <>
              For high-volume VPN, IoT, IIoT, edge, embedded networking, multi &
              hybrid cloud, Infrastructure as Code (IaC), and Commercial Use.
            </>
          }
          align="left"
          link=""
          color="#4436ca"
          rightSize="66.666%"
          leftSize="33%"
          rounded="rounded-xl"
          imgSize="376"
          textSize="text-size42"
        />
      </div>
    </div>
  );
}

export default Plan;
