import React, { useState } from "react";
import Logo from "./Logo";

function Header() {
  const [navigation] = useState([
    { name: "Features", id: 0 },
    { name: "Pricing", id: 1 },
    { name: "Download", id: 2 },
    { name: "Company", id: 3 },
    { name: "Support", id: 4 },
  ]);
  return (
    <div className="w-full header-bg-image">
      <div className="p-3 pt-8 wrapper flex justify-between">
        <div className="logo">
          <a aria-current="page" className="" href="/">
            {/* <span class="f32bja6m">Home</span> */}

            <Logo />
          </a>
        </div>
        <nav className="navigation lg:inline-block md:hidden  sm:hidden hidden">
          <ul className="flex pt-3">
            {navigation.map((item, index) => (
              <li key={index}>
                <a
                  href="/features"
                  className="text-xl text-white lg:px-5 px-3 hover:text-[#fdc17d]"
                >
                  {item.name}
                </a>
              </li>
            ))}
          </ul>
        </nav>
        <div className="loginPanel xl:pt-1 pt-0 flex items-center">
          <a
            href="/"
            className="text-xl text-white px-5 hover:text-[#fdc17d] xl:inline-block lg:inline-block hidden"
          >
            Login
          </a>
          <a
            href="/"
            className="text-xl text-black bg-[#ffb441] rounded-3xl p-[10px] px-6"
          >
            Sign Up
          </a>
          <div className="lg:hidden md:inline-block  sm:inline-block  ">
            <button
              className="text-[#ffb441] p-3 ml-3 relative top-1"
              title="Toggle menu"
            >
              <svg
                xmlns="http://www.w3.org/2000/svg"
                width="24"
                height="24"
                viewBox="0 0 24 24"
                fill="none"
                stroke="currentColor"
                stroke-width="2"
                stroke-linecap="round"
                stroke-linejoin="round"
              >
                <line x1="3" y1="12" x2="21" y2="12"></line>
                <line x1="3" y1="6" x2="21" y2="6"></line>
                <line x1="3" y1="18" x2="21" y2="18"></line>
              </svg>
            </button>
          </div>
        </div>
      </div>
      <div className="wrapper flex headermaskinng">
        {/* <div className="headermaskinng"></div> */}
        <div className="lg:w-[608px] w-full lg:p-0 p-5">
          <h1 className="main_heading">
            Securely connect any device, anywhere.
          </h1>
          <p className="sub_heading">
            ZeroTier lets you build modern, secure multi-point virtualized
            networks of almost any type. From robust peer-to-peer networking to
            multi-cloud mesh infrastructure, we enable global connectivity with
            the simplicity of a local network.
          </p>
          <div className="pt-8 text-left font-light">
            <a
              href="/"
              className="text-xl text-black bg-[#ffb441] rounded-3xl p-[10px] px-6 "
            >
              Get ZeroTier
            </a>
            <a
              href="/"
              className="text-xl text-white px-5 hover:text-[#fdc17d]"
            >
              Learn more
            </a>
          </div>
        </div>
        <div>&nbsp;</div>
      </div>
    </div>
  );
}

export default Header;
