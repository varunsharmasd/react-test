import Home from "./Screens/Home";

export const RoutesJSON = [{ path: "/", element: <Home />, id: 1 }];
