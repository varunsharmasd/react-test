import React from "react";
import Logo from "./Logo";
import { footerData } from "../data";

function Footer() {
  return (
    <footer className="pt-5 pb-10">
      <div className="wrapper ">
        <div className="flex justify-between xl:flex-row lg:flex-row md:flex-row flex-col xl:px-0 md:px-10 px-10">
          <div className="w-[340px]">
            <div className="flex flex-col">
              <Logo />
              <div className="mt-3 text-white text-left">
                Securely Connecting The World's Devices.
              </div>
            </div>
          </div>
          <div>&nbsp;</div>
          <div className="w-[654px]">
            <div className="flex xl:flex-row lg:flex-row md:flex-row flex-col">
              {footerData.map((item, index) => (
                <div
                  key={index}
                  className=" gap-5 w-3/6 xl:mb-0 lg:mb-0 md:mb-0 mb-10"
                >
                  <h3 className="text-white text-lg text-left">{item.title}</h3>
                  <ul>
                    {item.lists.map((childitem, childindex) => (
                      <li key={childindex} className="text-left py-1">
                        <a
                          href={childitem.link}
                          className="text-white text-lg font-thin"
                        >
                          {childitem.name}
                        </a>
                      </li>
                    ))}
                  </ul>
                </div>
              ))}
            </div>
          </div>
        </div>
        <div className="flex justify-between pt-10">
          <div className="text-white text-lg">
            © 2023 ZeroTier, Inc. All rights reserved.
          </div>
          <div className="flex-grow-1"></div>
          <ul className="flex">
            <li className="px-3">
              <a className="text-white text-lg" href="/terms/">
                <div className=" ">Terms</div>
              </a>
            </li>
            <li className="px-3">
              <a className="text-white text-lg" href="/privacy/">
                <div className=" ">Privacy Policy</div>
              </a>
            </li>
          </ul>
        </div>
      </div>
    </footer>
  );
}

export default Footer;
