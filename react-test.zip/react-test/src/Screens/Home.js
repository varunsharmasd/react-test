import React from "react";
import Header from "../_components/Header";
import Service from "../_components/Service";
import Teams from "../_components/Teams";
import Networks from "../_components/Networks";
import Pricing from "../_components/Pricing";
import Plan from "../_components/Plan";
import Footer from "../_components/Footer";

export default function Home() {
  return (
    <div>
      <Header />
      <div className="mb-10 mt-8">
        <div className="text-xl text-white pb-1">
          <p>
            🔔 NEW!
            <a href="/">ZeroTier Webhooks</a>- Current Release:
            <a href="https://www.zerotier.com/download/?utm_source=HPd">
              Download ZeroTier 1.12.2
            </a>
          </p>
        </div>
      </div>
      <Service />
      <Teams />
      <Networks />
      <Pricing />
      <Plan />
      <div className="py-10">
        <div className="wrapper p-8 bg-[#262626] rounded-xl ">
          <h3 className="text-size30 text-left text-white">
            Open Source Community Edition
          </h3>
          <p className="text-lg text-left text-white">
            Featuring unlimited nodes, networks, and admins. Self-hosted.
            Designed for non-Commercial Use cases.
          </p>
          <div className="pt-8 mb-3 text-left font-light">
            <a
              href="/"
              className="text-xl border-2 border-white text-white rounded-3xl p-[5px] px-5"
            >
              Get ZeroTier
            </a>
            <a
              href="/"
              className="text-xl text-white px-5 hover:text-[#fdc17d]"
            >
              Read Documentation
            </a>
          </div>
        </div>
      </div>
      <Footer />
    </div>
  );
}
